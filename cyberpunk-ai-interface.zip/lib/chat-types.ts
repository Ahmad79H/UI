export type Role = "user" | "assistant"

export interface ChatMessage {
  id: string
  role: Role
  /** decrypted internal thinking stream */
  reasoning: string
  /** final response stream */
  content: string
  /** whether tokens are still arriving for this message */
  streaming: boolean
  createdAt: number
}

export interface Session {
  id: string
  title: string
  messages: ChatMessage[]
  createdAt: number
}

export interface Agent {
  id: string
  name: string
  role: string
  tone: "neon" | "crimson" | "amber"
}

export const AGENTS: Agent[] = [
  { id: "orchestrator", name: "ORCHESTRATOR", role: "Task routing core", tone: "neon" },
  { id: "analyst", name: "ANALYST", role: "Deep reasoning unit", tone: "amber" },
  { id: "breaker", name: "RED_BREAKER", role: "Adversarial probe", tone: "crimson" },
]
