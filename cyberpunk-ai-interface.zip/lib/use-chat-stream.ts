"use client"

import { useCallback, useRef, useState } from "react"
import type { ChatMessage } from "@/lib/chat-types"

const ENDPOINT = "http://127.0.0.1:8000/api/chat/stream"

function uid() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`
}

/**
 * Parses a standard SSE stream from the backend.
 * Each event line looks like:  data: {"type":"reasoning","content":"..."}
 *                              data: {"type":"content","content":"..."}
 */
export function useChatStream() {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [streaming, setStreaming] = useState(false)
  const abortRef = useRef<AbortController | null>(null)

  const patchAssistant = useCallback(
    (id: string, patch: (m: ChatMessage) => ChatMessage) => {
      setMessages((prev) => prev.map((m) => (m.id === id ? patch(m) : m)))
    },
    [],
  )

  const reset = useCallback(() => {
    abortRef.current?.abort()
    setMessages([])
    setStreaming(false)
  }, [])

  const loadMessages = useCallback((msgs: ChatMessage[]) => {
    abortRef.current?.abort()
    setStreaming(false)
    setMessages(msgs)
  }, [])

  const stop = useCallback(() => {
    abortRef.current?.abort()
    setStreaming(false)
    setMessages((prev) =>
      prev.map((m) => (m.streaming ? { ...m, streaming: false } : m)),
    )
  }, [])

  const send = useCallback(
    async (text: string, agentId: string) => {
      const userMsg: ChatMessage = {
        id: uid(),
        role: "user",
        reasoning: "",
        content: text,
        streaming: false,
        createdAt: Date.now(),
      }
      const assistantId = uid()
      const assistantMsg: ChatMessage = {
        id: assistantId,
        role: "assistant",
        reasoning: "",
        content: "",
        streaming: true,
        createdAt: Date.now(),
      }
      setMessages((prev) => [...prev, userMsg, assistantMsg])
      setStreaming(true)

      const controller = new AbortController()
      abortRef.current = controller

      // typewriter queue so layout never stutters
      const queue: { type: "reasoning" | "content"; ch: string }[] = []
      let drained = false
      let rafActive = false

      const drain = () => {
        rafActive = true
        const batch = queue.splice(0, 3) // a few chars per frame
        if (batch.length) {
          patchAssistant(assistantId, (m) => {
            let { reasoning, content } = m
            for (const item of batch) {
              if (item.type === "reasoning") reasoning += item.ch
              else content += item.ch
            }
            return { ...m, reasoning, content }
          })
        }
        if (queue.length || !drained) {
          requestAnimationFrame(drain)
        } else {
          rafActive = false
          patchAssistant(assistantId, (m) => ({ ...m, streaming: false }))
          setStreaming(false)
        }
      }

      const enqueue = (type: "reasoning" | "content", chunk: string) => {
        for (const ch of chunk) queue.push({ type, ch })
        if (!rafActive) requestAnimationFrame(drain)
      }

      const handlePayload = (raw: string) => {
        const line = raw.trim()
        if (!line || !line.startsWith("data:")) return
        const json = line.slice(5).trim()
        if (json === "[DONE]") return
        try {
          const evt = JSON.parse(json) as { type: string; content: string }
          if (evt.type === "reasoning" || evt.type === "content") {
            enqueue(evt.type, evt.content ?? "")
          }
        } catch {
          /* ignore malformed frame */
        }
      }

      try {
        const res = await fetch(ENDPOINT, {
          method: "POST",
          headers: { "Content-Type": "application/json", Accept: "text/event-stream" },
          body: JSON.stringify({ message: text, agent: agentId }),
          signal: controller.signal,
        })
        if (!res.ok || !res.body) throw new Error(`status ${res.status}`)

        const reader = res.body.getReader()
        const decoder = new TextDecoder()
        let buffer = ""
        // read loop
        // eslint-disable-next-line no-constant-condition
        while (true) {
          const { value, done } = await reader.read()
          if (done) break
          buffer += decoder.decode(value, { stream: true })
          const parts = buffer.split("\n\n")
          buffer = parts.pop() ?? ""
          for (const part of parts) {
            for (const l of part.split("\n")) handlePayload(l)
          }
        }
        if (buffer) for (const l of buffer.split("\n")) handlePayload(l)
        drained = true
        if (!rafActive) {
          patchAssistant(assistantId, (m) => ({ ...m, streaming: false }))
          setStreaming(false)
        }
      } catch (err) {
        if (controller.signal.aborted) return
        // Backend unreachable → run a local simulated stream so the UI is demonstrable.
        await simulateStream(text, agentId, enqueue, controller.signal)
        drained = true
        if (!rafActive) {
          patchAssistant(assistantId, (m) => ({ ...m, streaming: false }))
          setStreaming(false)
        }
      }
    },
    [patchAssistant],
  )

  return { messages, streaming, send, stop, reset, loadMessages }
}

/* ── Local simulation fallback ─────────────────────────────
   Mimics the exact SSE payload shape the backend would emit. */
async function simulateStream(
  text: string,
  agentId: string,
  enqueue: (type: "reasoning" | "content", chunk: string) => void,
  signal: AbortSignal,
) {
  const reasoning = [
    `[INIT] Routing query through ${agentId.toUpperCase()} subroutine.\n`,
    `[PARSE] Decomposing operator intent: "${text.slice(0, 48)}${text.length > 48 ? "…" : ""}"\n`,
    "[VECTOR] Cross-referencing latent memory shards... 4 matches.\n",
    "[PLAN] Constructing response lattice. Confidence 0.94.\n",
    "[EMIT] Handing off to language core.",
  ].join("")

  const content =
    "Connection to local core 127.0.0.1:8000 was not detected, so this is a simulated tactical response. " +
    "Wire up your Nemotron backend to emit `data: {\"type\":\"reasoning\"...}` and " +
    "`data: {\"type\":\"content\"...}` frames and KHULASAAND will render them live, " +
    "segregating internal thought from the final stream automatically."

  const sleep = (ms: number) =>
    new Promise<void>((r) => {
      const t = setTimeout(r, ms)
      signal.addEventListener("abort", () => {
        clearTimeout(t)
        r()
      })
    })

  for (const word of reasoning.match(/\S+\s*/g) ?? []) {
    if (signal.aborted) return
    enqueue("reasoning", word)
    await sleep(28)
  }
  await sleep(260)
  for (const word of content.match(/\S+\s*/g) ?? []) {
    if (signal.aborted) return
    enqueue("content", word)
    await sleep(34)
  }
}
