"use client"

import { useState } from "react"
import { Sidebar } from "@/components/sidebar"
import { SystemHeader } from "@/components/system-header"
import { ChatFeed } from "@/components/chat-feed"
import { InputModule } from "@/components/input-module"
import { useChatStream } from "@/lib/use-chat-stream"
import { AGENTS, type Session } from "@/lib/chat-types"

export default function Page() {
  const { messages, streaming, send, stop, reset, loadMessages } = useChatStream()
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [activeAgent, setActiveAgent] = useState(AGENTS[0].id)
  const [sessions, setSessions] = useState<Session[]>([])
  const [activeSessionId, setActiveSessionId] = useState<string>("")

  function handleSend(text: string) {
    // intercept slash commands typed directly into the input
    if (text === "/new") return handleCommand("/new")
    if (text === "/save") return handleCommand("/save")
    if (text === "/clear") return handleCommand("/clear")
    send(text, activeAgent)
  }

  function handleCommand(cmd: "/new" | "/save" | "/clear") {
    if (cmd === "/clear") {
      reset()
      setActiveSessionId("")
      return
    }
    if (cmd === "/new") {
      reset()
      setActiveSessionId("")
      return
    }
    if (cmd === "/save") {
      if (messages.length === 0) return
      const firstUser = messages.find((m) => m.role === "user")
      const title = firstUser
        ? firstUser.content.slice(0, 26).toUpperCase()
        : `SESSION ${sessions.length + 1}`
      const id = `s-${Date.now().toString(36)}`
      const snapshot: Session = {
        id,
        title,
        messages: messages.map((m) => ({ ...m, streaming: false })),
        createdAt: Date.now(),
      }
      setSessions((prev) => [snapshot, ...prev])
      setActiveSessionId(id)
    }
  }

  function handleSelectSession(id: string) {
    const s = sessions.find((x) => x.id === id)
    if (!s) return
    setActiveSessionId(id)
    loadMessages(s.messages.map((m) => ({ ...m, streaming: false })))
  }

  return (
    <main className="flex h-screen w-full overflow-hidden bg-background">
      <Sidebar
        open={sidebarOpen}
        onToggle={() => setSidebarOpen((v) => !v)}
        sessions={sessions}
        activeSessionId={activeSessionId}
        onSelectSession={handleSelectSession}
        activeAgentId={activeAgent}
        onSelectAgent={setActiveAgent}
        onCommand={handleCommand}
      />

      <div className="flex min-w-0 flex-1 flex-col">
        <SystemHeader />
        <ChatFeed messages={messages} />
        <InputModule onSend={handleSend} onStop={stop} streaming={streaming} />
      </div>
    </main>
  )
}
