"use client"

import { Terminal, User } from "lucide-react"
import type { ChatMessage } from "@/lib/chat-types"
import { ReasoningAccordion } from "./reasoning-accordion"

export function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === "user"

  if (isUser) {
    return (
      <div className="flex justify-end">
        <div className="flex max-w-[85%] items-start gap-3 md:max-w-[70%]">
          <div className="clip-tactical border border-primary/40 bg-[#0a160e] box-glow px-4 py-2.5">
            <div className="mb-1 flex items-center gap-2">
              <span className="text-[10px] uppercase tracking-[0.2em] text-primary">OPERATOR</span>
            </div>
            <p className="whitespace-pre-wrap break-words text-sm leading-relaxed text-card-foreground">
              {message.content}
            </p>
          </div>
          <div className="mt-0.5 flex size-7 shrink-0 items-center justify-center border border-primary/40 bg-[#0a160e] text-primary">
            <User className="size-3.5" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex justify-start">
      <div className="flex w-full max-w-[92%] items-start gap-3 md:max-w-[80%]">
        <div className="mt-0.5 flex size-7 shrink-0 items-center justify-center border border-amber/50 bg-[#1a1305] text-amber">
          <Terminal className="size-3.5" />
        </div>
        <div className="min-w-0 flex-1">
          <ReasoningAccordion reasoning={message.reasoning} streaming={message.streaming && !message.content} />

          {(message.content || (message.streaming && message.reasoning)) && (
            <div className="clip-tactical-r border border-border bg-card px-4 py-3">
              <div className="mb-1.5 flex items-center gap-2">
                <span className="text-[10px] uppercase tracking-[0.2em] text-amber text-glow-amber">
                  KHULASAAND
                </span>
                <span className="h-px flex-1 bg-border" />
                {message.streaming && message.content && (
                  <span className="text-[9px] uppercase tracking-[0.2em] text-primary animate-neon-pulse">
                    STREAMING
                  </span>
                )}
              </div>
              <p className="whitespace-pre-wrap break-words text-sm leading-relaxed text-primary text-glow">
                {message.content}
                {message.streaming && message.content && (
                  <span className="caret" aria-hidden="true" />
                )}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
