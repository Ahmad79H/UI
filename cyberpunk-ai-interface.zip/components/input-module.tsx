"use client"

import { useRef, useState } from "react"
import { Send, Square } from "lucide-react"

export function InputModule({
  onSend,
  onStop,
  streaming,
}: {
  onSend: (text: string) => void
  onStop: () => void
  streaming: boolean
}) {
  const [value, setValue] = useState("")
  const [focused, setFocused] = useState(false)
  const taRef = useRef<HTMLTextAreaElement>(null)

  function submit() {
    const trimmed = value.trim()
    if (!trimmed || streaming) return
    onSend(trimmed)
    setValue("")
    if (taRef.current) taRef.current.style.height = "auto"
  }

  function handleKey(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      submit()
    }
  }

  function autoGrow(e: React.ChangeEvent<HTMLTextAreaElement>) {
    setValue(e.target.value)
    const el = e.target
    el.style.height = "auto"
    el.style.height = `${Math.min(el.scrollHeight, 160)}px`
  }

  return (
    <div className="shrink-0 border-t border-border bg-panel/80 p-3 backdrop-blur-sm md:p-4">
      <div
        className={`flex items-end gap-2 border bg-input px-3 py-2 transition-all clip-tactical ${
          focused ? "border-primary box-glow" : "border-border"
        }`}
      >
        <span className="select-none pb-1.5 text-sm font-bold text-primary text-glow">{">"}</span>
        <textarea
          ref={taRef}
          rows={1}
          value={value}
          onChange={autoGrow}
          onKeyDown={handleKey}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          placeholder="ENTER COMMAND // type a message or /new, /save, /clear"
          className="max-h-40 flex-1 resize-none bg-transparent py-1.5 text-sm leading-relaxed text-card-foreground placeholder:text-muted-foreground/70 focus:outline-none"
        />

        {streaming ? (
          <button
            type="button"
            onClick={onStop}
            aria-label="Abort stream"
            className="flex items-center gap-1.5 border border-crimson bg-crimson/10 px-3 py-2 text-crimson box-glow-crimson transition-colors hover:bg-crimson/20"
          >
            <Square className="size-3.5 fill-current" />
            <span className="text-[10px] font-bold uppercase tracking-[0.2em]">ABORT</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={submit}
            disabled={!value.trim()}
            aria-label="Execute"
            className={`flex items-center gap-1.5 border px-3 py-2 transition-all ${
              value.trim()
                ? "border-primary bg-primary/10 text-primary box-glow animate-neon-pulse hover:bg-primary/20"
                : "border-border bg-transparent text-muted-foreground"
            }`}
            style={
              value.trim()
                ? {
                    backgroundImage:
                      "repeating-linear-gradient(45deg, rgba(0,255,102,0.08) 0 4px, transparent 4px 8px)",
                  }
                : undefined
            }
          >
            <Send className="size-3.5" />
            <span className="text-[10px] font-bold uppercase tracking-[0.2em]">EXECUTE</span>
          </button>
        )}
      </div>
      <div className="mt-1.5 flex items-center justify-between px-1 text-[9px] uppercase tracking-[0.2em] text-muted-foreground">
        <span>ENTER → SEND • SHIFT+ENTER → NEWLINE</span>
        <span className="text-neon-dim">ENCRYPTION: AES-256 / SSE</span>
      </div>
    </div>
  )
}
