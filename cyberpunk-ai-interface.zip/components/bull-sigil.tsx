export function BullSigil({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 240 160"
      className={className}
      fill="none"
      stroke="currentColor"
      strokeWidth={3}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {/* Left horn */}
      <path d="M120 92 C96 96, 70 92, 52 74 C36 58, 30 38, 34 20 C50 30, 58 44, 66 56 C76 70, 92 80, 112 82" />
      {/* Right horn */}
      <path d="M120 92 C144 96, 170 92, 188 74 C204 58, 210 38, 206 20 C190 30, 182 44, 174 56 C164 70, 148 80, 128 82" />
      {/* Skull crown / brow */}
      <path d="M88 86 C88 70, 100 60, 120 60 C140 60, 152 70, 152 86 C152 104, 140 118, 120 124 C100 118, 88 104, 88 86 Z" />
      {/* Eyes */}
      <path d="M104 84 L114 90" strokeWidth={5} />
      <path d="M136 84 L126 90" strokeWidth={5} />
      {/* Snout / circuit nose */}
      <path d="M112 102 L120 110 L128 102" />
      <path d="M120 110 L120 122" />
      {/* Circuit nodes on horns */}
      <circle cx="34" cy="20" r="3.5" fill="currentColor" stroke="none" />
      <circle cx="206" cy="20" r="3.5" fill="currentColor" stroke="none" />
      <circle cx="52" cy="74" r="2.5" fill="currentColor" stroke="none" />
      <circle cx="188" cy="74" r="2.5" fill="currentColor" stroke="none" />
    </svg>
  )
}
