"use client"

import { Plus, Save, Trash2, History, ChevronLeft, Radio } from "lucide-react"
import { AGENTS, type Agent, type Session } from "@/lib/chat-types"

function toneText(tone: Agent["tone"]) {
  return tone === "crimson"
    ? "text-crimson"
    : tone === "amber"
      ? "text-amber"
      : "text-primary"
}
function toneBorder(tone: Agent["tone"], active: boolean) {
  if (!active) return "border-border"
  return tone === "crimson"
    ? "border-crimson box-glow-crimson"
    : tone === "amber"
      ? "border-amber"
      : "border-primary box-glow"
}

export function Sidebar({
  open,
  onToggle,
  sessions,
  activeSessionId,
  onSelectSession,
  activeAgentId,
  onSelectAgent,
  onCommand,
}: {
  open: boolean
  onToggle: () => void
  sessions: Session[]
  activeSessionId: string
  onSelectSession: (id: string) => void
  activeAgentId: string
  onSelectAgent: (id: string) => void
  onCommand: (cmd: "/new" | "/save" | "/clear") => void
}) {
  return (
    <aside
      className={`relative z-20 flex h-full shrink-0 flex-col border-r border-border bg-panel/90 backdrop-blur-sm transition-all duration-300 ${
        open ? "w-64" : "w-0 -translate-x-full md:w-12 md:translate-x-0"
      }`}
    >
      {/* collapse toggle */}
      <button
        type="button"
        onClick={onToggle}
        aria-label="Toggle sidebar"
        className="absolute -right-3 top-4 z-30 flex size-6 items-center justify-center border border-primary/50 bg-panel text-primary box-glow"
      >
        <ChevronLeft className={`size-3.5 transition-transform ${open ? "" : "rotate-180"}`} />
      </button>

      {!open && (
        <div className="hidden flex-col items-center gap-4 py-5 md:flex">
          <Radio className="size-4 text-primary animate-neon-pulse" />
          <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground [writing-mode:vertical-rl]">
            CONTROL DECK
          </span>
        </div>
      )}

      {open && (
        <div className="flex h-full flex-col overflow-hidden">
          {/* command rail */}
          <div className="border-b border-border p-3">
            <span className="mb-2 block text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
              {"// COMMAND RAIL"}
            </span>
            <div className="grid grid-cols-3 gap-1.5">
              <CmdBtn icon={<Plus className="size-3.5" />} label="/new" onClick={() => onCommand("/new")} />
              <CmdBtn icon={<Save className="size-3.5" />} label="/save" onClick={() => onCommand("/save")} />
              <CmdBtn icon={<Trash2 className="size-3.5" />} label="/clear" onClick={() => onCommand("/clear")} tone="crimson" />
            </div>
          </div>

          {/* agent selector */}
          <div className="border-b border-border p-3">
            <span className="mb-2 block text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
              {"// ACTIVE AGENT"}
            </span>
            <div className="flex flex-col gap-1.5">
              {AGENTS.map((a) => {
                const active = a.id === activeAgentId
                return (
                  <button
                    key={a.id}
                    type="button"
                    onClick={() => onSelectAgent(a.id)}
                    className={`flex items-center gap-2.5 border bg-[#0c0e13] px-2.5 py-2 text-left transition-colors clip-tactical-r ${toneBorder(a.tone, active)}`}
                  >
                    <span className={`size-2 ${active ? "animate-neon-pulse" : "opacity-40"} ${a.tone === "crimson" ? "bg-crimson" : a.tone === "amber" ? "bg-amber" : "bg-primary"}`} />
                    <span className="flex flex-col">
                      <span className={`text-[11px] font-bold uppercase tracking-[0.15em] ${active ? toneText(a.tone) : "text-secondary-foreground"}`}>
                        {a.name}
                      </span>
                      <span className="text-[9px] uppercase tracking-wider text-muted-foreground">{a.role}</span>
                    </span>
                  </button>
                )
              })}
            </div>
          </div>

          {/* session history */}
          <div className="flex min-h-0 flex-1 flex-col p-3">
            <span className="mb-2 flex items-center gap-1.5 text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
              <History className="size-3" /> SESSION LOGS
            </span>
            <div className="flex min-h-0 flex-1 flex-col gap-1 overflow-y-auto">
              {sessions.length === 0 && (
                <span className="px-1 text-[11px] text-muted-foreground">// no archived sessions</span>
              )}
              {sessions.map((s) => {
                const active = s.id === activeSessionId
                return (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => onSelectSession(s.id)}
                    className={`group flex items-center gap-2 border-l-2 px-2 py-1.5 text-left transition-colors ${
                      active
                        ? "border-primary bg-[#0a160e] text-primary"
                        : "border-transparent text-secondary-foreground hover:border-neon-dim hover:bg-[#0c0e13]"
                    }`}
                  >
                    <span className="text-[10px] text-muted-foreground">{">"}</span>
                    <span className="truncate text-[11px] tracking-wide">{s.title}</span>
                  </button>
                )
              })}
            </div>
          </div>

          {/* footer status */}
          <div className="border-t border-border px-3 py-2.5">
            <div className="flex items-center justify-between text-[9px] uppercase tracking-[0.2em] text-muted-foreground">
              <span>LINK</span>
              <span className="flex items-center gap-1 text-primary">
                <span className="size-1.5 bg-primary animate-neon-pulse" /> 127.0.0.1:8000
              </span>
            </div>
          </div>
        </div>
      )}
    </aside>
  )
}

function CmdBtn({
  icon,
  label,
  onClick,
  tone = "neon",
}: {
  icon: React.ReactNode
  label: string
  onClick: () => void
  tone?: "neon" | "crimson"
}) {
  const t =
    tone === "crimson"
      ? "border-crimson/40 text-crimson hover:bg-crimson/10"
      : "border-primary/40 text-primary hover:bg-primary/10"
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex flex-col items-center gap-1 border bg-[#0c0e13] py-2 transition-colors ${t}`}
    >
      {icon}
      <span className="text-[9px] uppercase tracking-wider">{label}</span>
    </button>
  )
}
