"use client"

import { BullSigil } from "./bull-sigil"

function Telemetry({
  label,
  value,
  tone = "neon",
}: {
  label: string
  value: string
  tone?: "neon" | "crimson" | "amber"
}) {
  const toneClass =
    tone === "crimson"
      ? "text-crimson text-glow-crimson"
      : tone === "amber"
        ? "text-amber text-glow-amber"
        : "text-primary text-glow"
  const dotClass =
    tone === "crimson" ? "bg-crimson" : tone === "amber" ? "bg-amber" : "bg-primary"
  return (
    <div className="flex items-center gap-2 whitespace-nowrap">
      <span className={`size-1.5 ${dotClass} animate-neon-pulse`} />
      <span className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{label}</span>
      <span className={`text-[10px] uppercase tracking-[0.18em] font-bold ${toneClass}`}>{value}</span>
    </div>
  )
}

export function SystemHeader() {
  return (
    <header className="relative shrink-0 border-b border-border bg-panel/80 backdrop-blur-sm">
      {/* moving scan line */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="scan-line h-px w-full bg-primary/40" />
      </div>

      <div className="relative flex items-center justify-between gap-4 px-4 py-3 md:px-6">
        {/* left identity */}
        <div className="hidden flex-col gap-1 md:flex">
          <span className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
            NODE // 0x4F-BULL
          </span>
          <span className="text-xs uppercase tracking-[0.2em] text-primary text-glow">
            TACTICAL LINK
          </span>
        </div>

        {/* center sigil + title */}
        <div className="flex flex-1 flex-col items-center">
          <div className="text-primary animate-sigil">
            <BullSigil className="h-14 w-auto md:h-16" />
          </div>
          <h1 className="mt-1 text-lg font-bold uppercase tracking-[0.45em] text-primary text-glow animate-flicker md:text-2xl">
            KHULASAAND
          </h1>
          <p className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
            {"// MULTI-AGENT NEURAL COMPANION"}
          </p>
        </div>

        {/* right telemetry */}
        <div className="hidden flex-col items-end gap-1.5 lg:flex">
          <Telemetry label="CORE ENGINE" value="ACTIVE" />
          <Telemetry label="MODEL" value="NEMOTRON 550B" tone="amber" />
          <Telemetry label="STREAM" value="SECURE_SSE" />
        </div>
      </div>

      {/* mobile telemetry strip */}
      <div className="flex items-center justify-around gap-2 border-t border-border/60 px-3 py-1.5 lg:hidden">
        <Telemetry label="CORE" value="ACTIVE" />
        <Telemetry label="MDL" value="NEMOTRON" tone="amber" />
        <Telemetry label="SSE" value="SECURE" />
      </div>
    </header>
  )
}
