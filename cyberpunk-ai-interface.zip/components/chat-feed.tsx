"use client"

import { useEffect, useRef } from "react"
import type { ChatMessage } from "@/lib/chat-types"
import { MessageBubble } from "./message-bubble"
import { BullSigil } from "./bull-sigil"

export function ChatFeed({ messages }: { messages: ChatMessage[] }) {
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" })
  }, [messages])

  return (
    <div className="relative min-h-0 flex-1 overflow-y-auto px-4 py-6 md:px-8">
      {messages.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="mx-auto flex max-w-3xl flex-col gap-5">
          {messages.map((m) => (
            <MessageBubble key={m.id} message={m} />
          ))}
          <div ref={bottomRef} />
        </div>
      )}
    </div>
  )
}

function EmptyState() {
  return (
    <div className="flex h-full flex-col items-center justify-center text-center">
      <div className="text-neon-dim animate-sigil">
        <BullSigil className="h-24 w-auto opacity-60" />
      </div>
      <p className="mt-6 text-sm uppercase tracking-[0.4em] text-primary text-glow">
        AWAITING DIRECTIVE
      </p>
      <p className="mt-2 max-w-sm text-[11px] leading-relaxed tracking-wider text-muted-foreground">
        {"// Neural link established. Transmit a command to wake the multi-agent core. "}
        {"Thought pathways will be decrypted in real time."}
      </p>
      <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
        {["ANALYZE THREAT VECTORS", "SUMMARIZE INTEL", "DRAFT EXPLOIT PLAN"].map((s) => (
          <span
            key={s}
            className="border border-neon-dim/50 bg-[#0a1410]/50 px-3 py-1 text-[10px] uppercase tracking-[0.15em] text-neon-dim"
          >
            {s}
          </span>
        ))}
      </div>
    </div>
  )
}
