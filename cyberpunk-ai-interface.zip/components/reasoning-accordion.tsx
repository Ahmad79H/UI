"use client"

import { useState } from "react"
import { ChevronRight, Cpu } from "lucide-react"

export function ReasoningAccordion({
  reasoning,
  streaming,
}: {
  reasoning: string
  streaming: boolean
}) {
  // auto-open while reasoning streams in, then collapsible by user
  const [manuallyClosed, setManuallyClosed] = useState(false)
  const open = streaming ? !manuallyClosed : !manuallyClosed

  if (!reasoning && !streaming) return null

  return (
    <div className="mb-2 border border-neon-dim/50 bg-[#0a1410]/60 clip-tactical-r">
      <button
        type="button"
        onClick={() => setManuallyClosed((v) => !v)}
        className="flex w-full items-center gap-2 px-3 py-2 text-left"
      >
        <Cpu className="size-3.5 text-neon-dim" />
        <span className="flex-1 text-[11px] uppercase tracking-[0.2em] text-neon-dim">
          {streaming ? "[ DECRYPTING THOUGHT PATHWAY... ]" : "[ THOUGHT PATHWAY // ARCHIVED ]"}
        </span>
        {streaming && <span className="size-1.5 bg-primary animate-neon-pulse" />}
        <ChevronRight
          className={`size-3.5 text-neon-dim transition-transform ${open ? "rotate-90" : ""}`}
        />
      </button>

      {open && (
        <div className="border-t border-neon-dim/30 px-3 py-2.5">
          <pre className="whitespace-pre-wrap break-words font-mono text-[12px] leading-relaxed text-[#6fae89]">
            {reasoning}
            {streaming && <span className="caret" aria-hidden="true" />}
          </pre>
        </div>
      )}
    </div>
  )
}
